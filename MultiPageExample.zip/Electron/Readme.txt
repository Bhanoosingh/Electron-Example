1)npm init(for project configration)
2)npm i electron --save-dev
3)npm i electron-reload --save-dev(to render application without relod)
	a)add in scripts "start": "electron index.js"
	b)add this code on index.js file
		const electron=require('electron')
		const {app,BrowserWindow}=electron

		app.on('ready',()=>{
    			let win=new BrowserWindow({width:800,height:800, 
        			webPreferences: {
                			nodeIntegration: true
        			}
    			})
    			win.loadURL(`file://${__dirname}/index.html`)
		})

	c) add index.html and page2.html(for multiple page)
4)npm start(To run app)